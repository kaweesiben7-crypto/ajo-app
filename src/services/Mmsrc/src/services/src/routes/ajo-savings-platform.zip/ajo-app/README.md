# Ajo — Rotating Savings Circle Platform

A digital version of a rotating savings group (ajo / esusu / tontine / chama).
Members join a group, pay a fixed contribution every week, and each round the
full pooled amount is disbursed to one member — in fixed sign-up order — until
everyone has received exactly one payout. **No investment returns are promised
or paid; members only ever receive back what the group collectively contributes.**

## How the model works
- Each group has: contribution amount, currency, max members, weekly cycle.
- Payout order = sign-up order (member 1 gets round 1, member 2 gets round 2, etc).
- A round only pays out once **every** member's contribution for that round is confirmed.
- After every member has been paid once, the group is marked `completed`.
- Referrals earn a small platform-fee rebate (`referral_rewards` table) — not a return on deposit.

## Setup

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Create the database**
   ```bash
   createdb ajo_db
   npm run migrate
   ```

3. **Configure environment**
   Copy `.env.example` to `.env` and fill in:
   - `DATABASE_URL`, `JWT_SECRET`
   - MTN MoMo sandbox/production credentials from https://momodeveloper.mtn.com
   - Airtel Money credentials from https://developers.airtel.africa

4. **Run**
   ```bash
   npm run dev
   ```

## Before going live (important)

Both providers require real business onboarding before you can move real money:

- **MTN MoMo**: register on the developer portal, subscribe to both the
  Collections and Disbursements products, provision an API user + API key for
  each in sandbox, test fully, then request production access and credentials
  for each country you operate in (URLs and target-environment codes differ
  per country).
- **Airtel Money**: register as a developer, create an app for `client_id` /
  `client_secret`, and request access to the Collections and Disbursements
  products for your country. Airtel's disbursement endpoint requires the
  payout PIN to be RSA-encrypted with a certificate they issue — the
  `sendPayout` function in `src/services/airtelMoney.js` has a placeholder for
  this (`AIRTEL_DISBURSEMENT_PIN`); implement their encryption spec before
  using it with real money.
- You'll likely also need to register as a licensed or authorized payment
  aggregator/agent in whichever country you launch in — check local
  telecom/financial regulations before handling other people's money.

## API overview

| Endpoint | Method | Description |
|---|---|---|
| `/api/auth/register` | POST | Create account (name, phone, provider, password, optional referral code) |
| `/api/auth/login` | POST | Log in, returns JWT |
| `/api/groups` | POST | Create a group (creator becomes payout position 1) |
| `/api/groups/open` | GET | List groups still accepting members |
| `/api/groups/:id` | GET | Group detail + members in payout order |
| `/api/groups/:id/join` | POST | Join a group (assigned next payout position) |
| `/api/contributions/:groupId/pay` | POST | Trigger a MoMo/Airtel payment prompt for this round |
| `/api/contributions/:groupId/status/:round` | GET | Poll contribution status |
| `/api/payouts/:groupId/trigger` | POST | Manually trigger this round's payout (also runs automatically hourly via cron once a round is fully funded) |
| `/api/payouts/:groupId/history` | GET | Payout history for a group |

## Notes
- The weekly cycle job (`src/jobs/weeklyCycle.js`) checks every active group
  hourly and disburses automatically the moment all members for the current
  round have paid — it does not wait for a fixed calendar day, so a group that
  fills its round early pays out early.
- Add a webhook receiver for MTN/Airtel payment callbacks if you want instant
  confirmation instead of polling (`checkContributionStatus` polling is used
  here for simplicity).
