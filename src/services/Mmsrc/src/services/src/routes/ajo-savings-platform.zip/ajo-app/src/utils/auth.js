const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

function hashPassword(plain) {
  return bcrypt.hash(plain, 10);
}

function comparePassword(plain, hash) {
  return bcrypt.compare(plain, hash);
}

function signToken(user) {
  return jwt.sign(
    { id: user.id, phone_number: user.phone_number },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
}

module.exports = { hashPassword, comparePassword, signToken };
